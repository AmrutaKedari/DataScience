# app.py
import dash
from dash import html, dcc, Input, Output, State
import plotly.express as px
import pandas as pd

# --- Load or create data (replace with your csv / dataframe)
# Example: df = pd.read_csv('yourdata.csv')
# For demonstration, we'll use the df from earlier; replace this with your real df
import numpy as np
np.random.seed(0)
years = np.repeat(np.arange(2006, 2021), 12)
months = list(range(1,13)) * (2021-2006)
vehicle_types = ['Car','SUV','Truck']
rows = len(years)
df = pd.DataFrame({
    'year': years,
    'month': months,
    'vehicle_type': np.random.choice(vehicle_types, size=rows, p=[0.5,0.35,0.15]),
    'sales': np.random.poisson(lam=200, size=rows),
    'gdp': np.random.normal(10000, 300, size=rows) + np.where((years>=2008)&(years<=2009), -500, 0),
    'price_avg': np.random.normal(30000, 2000, size=rows),
    'advertising': np.random.uniform(20000, 100000, size=rows),
    'unemployment': np.random.uniform(3.0, 11.0, size=rows)
})
df['recession'] = df['year'].isin([2008,2009])

# --- Initialize Dash app
app = dash.Dash(__name__)
server = app.server

app.layout = html.Div([
    html.H1("Automobile Sales — Recession vs Non-Recession Dashboard", style={'textAlign':'center'}),
    html.Div([
        html.Div([
            html.Label("Select Vehicle Type"),
            dcc.Dropdown(
                id='vehicle-dropdown',
                options=[{'label':t,'value':t} for t in sorted(df['vehicle_type'].unique())],
                value='Car',
                clearable=False
            ),
        ], style={'width':'30%', 'display':'inline-block', 'padding':'10px'}),
        html.Div([
            html.Label("Select Year"),
            dcc.Dropdown(
                id='year-dropdown',
                options=[{'label':str(y),'value':y} for y in sorted(df['year'].unique())],
                value=2020,
                clearable=False
            )
        ], style={'width':'25%', 'display':'inline-block', 'padding':'10px'}),
        html.Div([
            html.Label("Recession Filter"),
            dcc.Dropdown(
                id='recession-dropdown',
                options=[
                    {'label':'All','value':'all'},
                    {'label':'Recession','value':'recession'},
                    {'label':'Non-Recession','value':'nonrecession'}
                ],
                value='all',
                clearable=False
            )
        ], style={'width':'20%', 'display':'inline-block', 'padding':'10px'})
    ], className='controls'),

    # output division for graphs & stats (TASK 2.3)
    html.Div(id='output-container', className='dashboard-output', children=[
        html.Div(id='summary-stats', style={'padding':'10px'}),
        dcc.Graph(id='time-series-graph'),
        dcc.Graph(id='recession-stats-graph')
    ]),

    html.Div(id='hidden-div', style={'display':'none'})  # can be used for debugging/state
], style={'maxWidth':'1200px','margin':'0 auto'})
# --- Callbacks (TASK 2.4)
@app.callback(
    Output('time-series-graph','figure'),
    Output('recession-stats-graph','figure'),
    Output('summary-stats','children'),
    Input('vehicle-dropdown','value'),
    Input('year-dropdown','value'),
    Input('recession-dropdown','value')
)
def update_dashboard(vehicle_type, year, recession_filter):
    # Filter dataset
    dff = df.copy()
    if recession_filter == 'recession':
        dff = dff[dff['recession']==True]
    elif recession_filter == 'nonrecession':
        dff = dff[dff['recession']==False]

    # Time series: yearly sales for chosen vehicle_type
    ts = dff[dff['vehicle_type']==vehicle_type].groupby('year')['sales'].sum().reset_index()
    fig_ts = px.line(ts, x='year', y='sales', markers=True, title=f'Yearly Sales for {vehicle_type}')

    # Recession stats graph: compare avg sales and unemployment (bar + line)
    rec_agg = dff.groupby('year').agg({'sales':'sum','unemployment':'mean'}).reset_index()
    fig_recession = px.bar(rec_agg, x='year', y='sales', title='Yearly Total Sales (with Unemployment overlay)')
    fig_recession.add_scatter(x=rec_agg['year'], y=rec_agg['unemployment']*10, mode='lines+markers', name='Unemployment (scaled)')
    # note: scaling unemployment so it fits on same y-axis; in production use secondary y-axis

    # Summary stats for chosen year
    dff_year = dff[dff['year']==year]
    total_sales_year = int(dff_year['sales'].sum())
    avg_price = dff_year['price_avg'].mean()
    adv_spend = dff_year['advertising'].sum()

    summary = html.Div([
        html.H4(f"Summary for Year {year} — Filter: {recession_filter}, Vehicle: {vehicle_type}"),
        html.P(f"Total Sales: {total_sales_year}"),
        html.P(f"Average Price: ${avg_price:,.0f}"),
        html.P(f"Advertising Spend: ${adv_spend:,.0f}")
    ])

    return fig_ts, fig_recession, summary

if __name__ == '__main__':
    # ✅ Correct for Dash v3+
    app.run(debug=True)

